import { useMemo } from "react";
import "./styles/grid.css";

interface AppProps {
  name: string;
  url: string;
}

const mockApps: AppProps[] = [
  {
    name: "App1",
    url: "app1",
  },
  {
    name: "App2",
    url: "app2",
  },
  {
    name: "App3",
    url: "app3",
  },
];

function App() {
  const initUrl = useMemo(() => window.location.href, []);
  const handleRedirect = (url: string) =>
    window.location.replace(initUrl + url);
  return (
    <div className="gridContainer">
      <ul className="listContainer">
        {mockApps.map((app) => (
          <li className="listItem" onClick={() => handleRedirect(app.url)}>
            <span>{app.name}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
